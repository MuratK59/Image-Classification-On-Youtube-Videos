var firebaseConfig = {
    apiKey: "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX", //API Key
    authDomain: "XXXXXXXX.firebaseapp.com",
    databaseURL: "https://XXXXXXXXXX.firebaseio.com",
    projectId: "XXXXXXXXXXX",
    storageBucket: "XXXXXXXXX.appspot.com",
    messagingSenderId: "1023827940164",
    appId: "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" //API ID
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);

//database örneği oluştur
const database=firebase.database();//firebase db nin bir örneği alınır.
const rootref=database.ref("tespit");

//sayfa yüklenirken db de kayıtlı mı kontrol ediyoruz
chrome.tabs.onUpdated.addListener( function (tabId, changeInfo, tab) {
    if (changeInfo.status == 'complete' && tab.active && tab.url.startsWith("https://www.youtube.com/") && tab.url!="https://www.youtube.com/") {
        //youtube dışında sayfalar bizi ilgilendirmiyor.
        console.log("Yüklenen Sayfa :" + tab.url);

        //video id sini öğrenme
        var video_id = tab.url.split('v=')[1];
        
        rootref.orderByChild("videoID").equalTo(video_id).on("value", snapshot =>{ 
            if (snapshot.val()!=null) {
                var notifOptions = {
                    type: 'basic',
                    iconUrl: 'icon48.png',
                    title: 'Görüntülenen Video Zararlı',
                    message: 'İzlediğiniz Video Sizin İçin Uygun Değildir!!!'
                };
                chrome.notifications.create('tespitNotif', notifOptions);
                //aktif tab ın url ini değiştir
                chrome.tabs.query({currentWindow: true, active: true}, function (tab) {
                    chrome.tabs.update(tab.id, {url: "https://www.youtube.com/"});
              });
            }
        });
    }
});

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse){
    if (request.todo == "showPageAction") {
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs){
            chrome.pageAction.show(tabs[0].id);
            chrome.tabs.sendMessage(tabs[0].id, {todo: "modeliBaslat"});
            chrome.alarms.create('refresh', { periodInMinutes:0.05 });
        });
    }else if(request.todo == "addToList"){
        //kullanıcıyı bilgilendir
        var notifOptions = {
            type: 'basic',
            iconUrl: 'icon48.png',
            title: 'Zararlı İçerik Tespit Edildi!',
            message: 'İzlediğiniz Video Sizin İçin Uygun Değildir!!!'
        };
        chrome.notifications.create('tespitNotif', notifOptions);

        console.log("Tespit: " + request.sinifAdi + " videoID:" + request.video_id + " baslik: " + request.videoBaslik);
        
        rootref.orderByChild("videoID").equalTo(request.video_id).on("value", snapshot =>{ 
            if (snapshot.val()==null) {
                const autoid=rootref.push().key;
        
                chrome.storage.local.get(['kimlik'], function(result) {
                    var today = new Date();
                    var dd = String(today.getDate()).padStart(2, '0');
                    var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
                    var yyyy = today.getFullYear();
                    today = yyyy + '-' + mm + '-' + dd;
                    document.write(today);

                    rootref.child(autoid).set({
                        videoID: request.video_id,
                        baslik: request.videoBaslik,
                        icerik: request.sinifAdi,
                        tarih: today,
                        yapan: result.kimlik
                    }); 
                });
            } else {
                console.log(snapshot.val());
            }
        });
    }
});

//tanımlama için periyodik çalışan timer
chrome.alarms.onAlarm.addListener((alarm) => {
    console.log(alarm.name); // refresh
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs){
        //console.log("TABID:"+tabs[0]);//hatanın sebebini bulamadım
        if (tabs[0].url.startsWith("https://www.youtube.com/") && tabs[0].url!="https://www.youtube.com/") {
            chrome.tabs.sendMessage(tabs[0].id, {todo: "tanimlamaYap"});
        }
    });
});

//on installed/updated
chrome.runtime.onInstalled.addListener(() => {
    console.log('onInstalled....');
    kimlik();
});

//when chrome restarted
chrome.runtime.onStartup.addListener(() => {
    console.log('onStartup....');
    kimlik();
});

function kimlik() {
    chrome.storage.local.get(['kimlik'], function(result) {
        if (result.kimlik===undefined) {
            var deger=uuidv4();
            function uuidv4() {
                return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, c =>
                (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
                )
            }
            chrome.storage.local.set({kimlik: deger}, function() {
                console.log('Kimlik Olusturuldu: ' + deger);
            });
        } else {
            console.log('Gecerli Kimlik: ' + result.kimlik);
        }
    });
}