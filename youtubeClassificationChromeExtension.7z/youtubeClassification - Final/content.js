chrome.runtime.sendMessage({todo: "showPageAction"});
var model;
var canvas;
var context;   
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse){
    
    async function loadModel(){
        model = undefined;
        console.log(model);
        const MODEL_URL = 'http://127.0.0.1:8887/model.json';
        //const MODEL_URL = 'https://firebasestorage.googleapis.com/v0/b/mktez-c305f.appspot.com/o/model.json?alt=media&token=b8bcb795-3ff4-4a05-9696-cf646c83952d';
        model = await tf.loadLayersModel(MODEL_URL);
        console.log("Model Loaded...");
    }


    if (request.todo == "modeliBaslat") {
        loadModel();
        console.log("Model Loading................");
        //canvas nesnesi oluştur ve hazırla
        var cnvs = document.createElement("canvas");
        var yeri = document.getElementById("container");
        yeri.insertBefore(cnvs, yeri.childNodes[0]);
        canvas = document.querySelector('canvas');
        canvas.width = 224;
        canvas.height = 224;
        context = canvas.getContext('2d');

    }else if (request.todo == "tanimlamaYap") {
        //video id sini öğrenme
        var video_id = window.location.search.split('v=')[1];
        var ampersandPosition = video_id.indexOf('&');
        if(ampersandPosition != -1) {
            video_id = video_id.substring(0, ampersandPosition);
        }
        console.log("Tetiklendi.............." + video_id);         
        //window.setInterval( snap, 3000)//3 saniyede bir çalıştır

        //resmi al ve videonun durumunda göre modele sok ya da bir şey yapma
        var video = document.querySelector('video');
        if (!video.ended && !video.paused) {
            // Grab the image from the video
            context.drawImage(video, 0, 0, 224, 224);
            //console.log("Canvasa Çizildi");
            tahmin();
        } else {
            console.log("Video sonu veya pause");
            //video yürütülmüyorsa canvası kaldır
            //yeri.removeChild(yeri.childNodes[0]);
        }

        //modelimizi uyguladığımız yer
        async function tahmin(){
            //console.log("TAHMİN");
            var image = tf.browser.fromPixels(canvas);
            //const image = tf.browser.fromPixels(imgcanvas);
            //const resized_image = tf.image.resizeBilinear(image, [224,224]).toFloat();
            var offset = tf.scalar(255.0);
            //const normalized = tf.scalar(1.0).sub(resized_image.div(offset));
            var normalized = tf.scalar(1.0).sub(image.div(offset));
            var batchedImage = normalized.expandDims(0);         
            
            //const result = model.predict(batchedImage);
            //result.print();

            //harici js dosyası yaptım
            const MODEL_CLASSES = {
                0: 'Sigara',
                1: 'Silah',
                2: 'Zararlı İçecek'
            }
            if (model == undefined) {
                console.log("Model Henüz Yüklenmedi...");             
            }else{
                var predictions  = await model.predict(batchedImage).data();
                var results = Array.from(predictions)
                .map(function (p, i) {
                    return {
                        probability: p,
                        className: MODEL_CLASSES[i]
                    };
                });  

                var sinifAdi = "";
                var olasilik = 0;
                results.forEach(function (p) {
                    console.log(p.className + " " + p.probability.toFixed(3));
                    if (parseFloat(p.probability)>olasilik) {
                        olasilik=p.probability;
                        sinifAdi=p.className;
                    }
                });               

                 //video başlığını okudum
                var videoBaslik= document.querySelector("title").childNodes[0].textContent;

                //sınıflar içerisinde en büyük olasılığı bul
                if (olasilik>0.95) {
                    //console.log("Görüntü Tahmini " + sinifAdi + " " + olasilik.toFixed(3) + " başlık: " + videoBaslik);//en büyük sonuç   
                    chrome.runtime.sendMessage({
                        todo: "addToList", 
                        video_id: video_id,
                        videoBaslik: videoBaslik,
                        sinifAdi: sinifAdi
                    });
                    //tespit yapıldı url değiştir
                    location.replace("https://www.youtube.com/");
                }
                
                //chrome da ram doldurmasını engellemek için
                image.dispose();
                offset.dispose();
                normalized.dispose();
                batchedImage.dispose();
                results= null;
                predictions= null;

                video_id= null;
                ampersandPosition= null;
                olasilik= null;
                videoBaslik= null;
                sinifAdi= null;

            }
            //canvası kaldır
            //yeri.removeChild(yeri.childNodes[0]);
        }
    }
});