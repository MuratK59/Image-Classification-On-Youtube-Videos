var firebaseConfig = {
    apiKey: "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX", //API Key
    authDomain: "XXXXXXXX.firebaseapp.com",
    databaseURL: "https://XXXXXXXXXX.firebaseio.com",
    projectId: "XXXXXXXXXXX",
    storageBucket: "XXXXXXXXX.appspot.com",
    messagingSenderId: "1023827940164",
    appId: "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" //API ID
};

firebase.initializeApp(firebaseConfig);

//database örneği oluştur
const database=firebase.database();//firebase db nin bir örneği alınır.
const rootref=database.ref("tespit");

chrome.storage.local.get(['kimlik'], function(result) {
    rootref.orderByChild("yapan").equalTo(result.kimlik).limitToLast(25).on("value", snapshot =>{
        document.getElementById("liste").innerHTML = '';
        snapshot.forEach(item => {
            var node = document.createElement("li");
            var textnode = document.createTextNode(item.val().tarih + " : " + item.val().baslik);
            node.appendChild(textnode);
            document.getElementById("liste").appendChild(node);
        });
    });
});